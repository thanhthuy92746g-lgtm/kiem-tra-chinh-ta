# Mô hình VietSpell: Wikipedia + OPUS/OpenSubtitles

Mô hình n-gram ngoại tuyến mới được huấn luyện cho dự án, không phải mô hình của bản tham chiếu. Không dùng câu mẫu tự soạn để huấn luyện mô hình này.

- Wikipedia dump `viwiki-20261001-pages-articles.xml.bz2`: 80.000 bài huấn luyện, đã kiểm tra MD5 từ Wikimedia.
- OPUS/OpenSubtitles v2018 tiếng Việt: toàn bộ phần còn lại sau khi giữ riêng các câu kiểm tra; đọc gzip hoàn tất.
- 8,169,345 câu huấn luyện; 78,064,093 lượt âm tiết quan sát hợp lệ; 78,060,212 lượt sau lọc unigram hiếm.
- 7,880 unigram; 816.675 bigram; 1.666.758 trigram.
- SQLite: 54,079,488 byte (51,6 MiB).
- SHA-256: `52847125dd6f51d79fe956b19ea3150ee1abb3a634201198c8afcb7e47e121d8`.
- Ngưỡng số đếm: unigram ≥4, bigram ≥4, trigram ≥5. Xác suất nội suy cố định 0,75 / 0,65; add-0,5.
- Nguồn, hash ngữ liệu/mã huấn luyện và cách chia dữ liệu: `model-provenance.json`.

## Kiểm chứng hành vi

Cả 17 kiểm tra sản phẩm qua `tools/validate_model.py` đều đạt trên chính mô hình này: ba lỗi mẫu, câu mất dấu, giữ Tôi/đang, không sửa cống Đôi, viết hoa Nhất và các ca sạch. Đây là kiểm tra hành vi đã biết, không phải phép đo tổng quát về độ chính xác.

## Đo phát triển trên câu giữ riêng

300 câu Wikipedia (5.801 token chữ) và 300 câu hội thoại (2.665 token chữ) không nằm trong huấn luyện n-gram; loại câu trùng theo chuỗi token khỏi cả hai nguồn. Chia theo phần đầu ngữ liệu, không phải mẫu ngẫu nhiên đại diện mọi văn bản. Các câu này đã được dùng chẩn đoán quy tắc bộ soát, nên số dưới đây **không phải kiểm định mù cuối cùng**.

Bảng tính các phát hiện ngôn ngữ, không gồm viết hoa, dấu câu hoặc thể thức Word. Câu gốc có thể có lỗi thật, từ phiên âm, tên riêng hoặc từ ngoại lai; “có phát hiện” không đồng nghĩa chắc chắn báo nhầm. Các lỗi nhân tạo được tạo độc lập từng loại, tối đa một lỗi/câu đủ điều kiện. “Phát hiện” gồm cả cảnh báo âm tiết lạ không có gợi ý. Gợi ý đầu đúng là số ca gợi ý đầu trùng từ gốc / tổng ca đủ điều kiện.

| Tập | Mức | Câu gốc có phát hiện | Token gốc bị đánh dấu | Phương ngữ: phát hiện / gợi ý đầu đúng | Gõ thiếu 1 ký tự: phát hiện / gợi ý đầu đúng | Bỏ dấu: phát hiện / gợi ý đầu đúng |
| --- | --- | --- | --- | --- | --- | --- |
| Wikipedia | Cân bằng | 59/300 (19.7%) | 1.3% | 93.0% / 68.6% | 77.7% / 54.0% | 86.3% / 82.3% |
| Wikipedia | Chặt | 44/300 (14.7%) | 1.0% | 55.2% / 28.8% | 52.7% / 3.0% | 75.3% / 73.3% |
| Hội thoại OPUS | Cân bằng | 14/300 (4.7%) | 0.6% | 94.4% / 75.3% | 88.7% / 63.5% | 92.7% / 87.7% |
| Hội thoại OPUS | Chặt | 5/300 (1.7%) | 0.3% | 56.4% / 30.0% | 62.4% / 0.0% | 82.0% / 77.0% |

Báo cáo JSON lưu cả top 5, mẫu số mỗi nhóm, phân bố rule, ví dụ phát hiện, cấu hình và hash mã bộ soát. Mức Chặt giảm gợi ý gây nhiễu, đồng thời bỏ sót nhiều lỗi gõ; không hiểu số “phát hiện” là số đã sửa đúng. Ngưỡng mặc định Cân bằng vẫn theo đặc tả; ứng viên đổi hai ký tự có tiên nghiệm thấp hơn, và tên/ký hiệu/đơn vị được miễn soát thận trọng.

## Giới hạn và sử dụng

Chưa có tập lỗi hành chính tự nhiên được người gán nhãn độc lập. Không tuyên bố tái lập các tỉ lệ của bản tham chiếu. Bộ sinh âm tiết sinh 25.481 dạng, thấp hơn 41.632 dạng tham chiếu; một số từ hiếm/ngoại lai có thể bị báo âm tiết lạ. Cách làm sạch wiki chưa tương đương một trình render MediaWiki đầy đủ. Tên nước ngoài giống lỗi gõ và từ viết hoa không dấu có thể được miễn soát để giảm báo nhầm.

Mô hình chỉ đọc, không có truy cập mạng khi chạy ứng dụng. Giữ quyền quyết định của người dùng, xem từng gợi ý trước khi xuất bản Word mới. Không dùng Chấp nhận tất cả cho văn bản quan trọng khi chưa duyệt ngữ cảnh.

## Ghi công dữ liệu

Wikipedia tiếng Việt — cộng đồng tác giả Wikimedia, https://vi.wikipedia.org/ và dump Wikimedia; CC BY-SA 4.0, bản giấy phép kèm `licenses/Qt/CC-BY-SA-4.0.txt` trong sản phẩm Windows và `resources/licenses/CC-BY-SA-4.0.txt` trong mã nguồn. Đây là số đếm thống kê được trích xuất và lọc, không phải nguyên văn toàn bộ bài viết. OPUS/OpenSubtitles — OPUS, OpenSubtitles.org; https://opus.nlpl.eu/OpenSubtitles.php và https://www.opensubtitles.org/ . Xem THIRD-PARTY-NOTICES.md và điều kiện của nguồn khi phân phối lại. Mã nguồn ứng dụng được cấp MIT, không thay thế giấy phép dữ liệu.
